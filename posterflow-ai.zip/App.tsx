
import React, { useState, useEffect } from 'react';
import PosterForm from './components/PosterForm';
import PosterCard from './components/PosterCard';
import AIAgent from './components/AIAgent';
import Pricing from './components/Pricing';
import Auth from './components/Auth';
import { PosterConfig, GeneratedPoster, AppView } from './types';
import { generatePosterImage } from './services/geminiService';

const App: React.FC = () => {
  const [history, setHistory] = useState<GeneratedPoster[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<AppView>('studio');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('poster_history');
    if (saved) {
      try { setHistory(JSON.parse(saved)); } catch (e) { console.error(e); }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('poster_history', JSON.stringify(history));
  }, [history]);

  const handleGenerate = async (config: PosterConfig) => {
    setIsGenerating(true);
    setError(null);
    try {
      if (config.highQuality) {
        const hasKey = await (window as any).aistudio.hasSelectedApiKey();
        if (!hasKey) await (window as any).aistudio.openSelectKey();
      }
      const imageUrl = await generatePosterImage(config);
      const newPoster: GeneratedPoster = {
        id: crypto.randomUUID(),
        url: imageUrl,
        config: { ...config },
        timestamp: Date.now(),
      };
      setHistory(prev => [newPoster, ...prev]);
    } catch (err: any) {
      if (err.message === 'API_KEY_RESET_REQUIRED') {
        setError("Pro engine requires a paid API key. Please select a key.");
        await (window as any).aistudio.openSelectKey();
      } else {
        setError("Generation failed. Please check your connection or prompt.");
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = (url: string, title: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = `Design_${title || 'Poster'}.png`;
    link.click();
  };

  const renderContent = () => {
    switch (currentView) {
      case 'pricing':
        return <Pricing />;
      case 'login':
        return <Auth initialMode="login" onComplete={() => { setIsLoggedIn(true); setCurrentView('studio'); }} onSwitch={setCurrentView} />;
      case 'signup':
        return <Auth initialMode="signup" onComplete={() => { setIsLoggedIn(true); setCurrentView('studio'); }} onSwitch={setCurrentView} />;
      case 'studio':
      default:
        return (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start animate-in fade-in duration-700">
            <div className="lg:col-span-4 lg:sticky lg:top-32">
              <PosterForm onGenerate={handleGenerate} isGenerating={isGenerating} />
              {error && (
                <div className="mt-6 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl text-red-400 text-xs font-bold flex items-center gap-3">
                  <div className="w-2 h-2 bg-red-500 rounded-full animate-ping" />
                  {error}
                </div>
              )}
            </div>

            <div className="lg:col-span-8">
              <div className="flex items-end justify-between mb-8 border-l-4 border-indigo-600 pl-6 py-2">
                <div>
                  <h2 className="text-3xl font-black text-slate-900 tracking-tight">Gallery</h2>
                  <p className="text-slate-500 text-sm font-medium">Your generated masterpieces in one place.</p>
                </div>
                <div className="flex gap-2">
                  <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-400 hover:text-indigo-600 transition-colors cursor-pointer">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
                    </svg>
                  </div>
                </div>
              </div>

              {history.length === 0 && !isGenerating ? (
                <div className="flex flex-col items-center justify-center py-32 bg-slate-50 border border-slate-100 rounded-[40px] text-center px-12 group hover:border-indigo-500/20 transition-all">
                  <div className="w-24 h-24 bg-white rounded-[30px] flex items-center justify-center mb-8 border border-slate-200 group-hover:scale-110 group-hover:rotate-6 transition-transform shadow-sm">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-slate-300 group-hover:text-indigo-500 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-black text-slate-900 mb-3">Begin Your Design Journey</h3>
                  <p className="text-slate-500 max-w-sm leading-relaxed text-sm font-medium italic">"Every great poster starts with a single prompt." — Flow AI</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                  {isGenerating && (
                    <div className="aspect-[3/4] rounded-3xl border border-indigo-500/20 bg-indigo-50/30 backdrop-blur-sm overflow-hidden flex flex-col items-center justify-center p-8 text-center relative">
                      <div className="absolute inset-0 bg-gradient-to-t from-indigo-500/5 to-transparent animate-pulse" />
                      <div className="w-16 h-16 border-[6px] border-slate-100 border-t-indigo-500 rounded-full animate-spin mb-6" />
                      <p className="text-slate-900 text-lg font-black italic tracking-widest uppercase">Synthesizing...</p>
                      <p className="text-indigo-600/60 text-[10px] font-bold mt-2 uppercase tracking-[0.3em]">Crafting Every Pixel</p>
                    </div>
                  )}
                  {history.map((poster) => (
                    <PosterCard 
                      key={poster.id} 
                      poster={poster} 
                      onDownload={handleDownload}
                      onDelete={(id) => setHistory(prev => prev.filter(p => p.id !== id))}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 selection:bg-indigo-100">
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none overflow-hidden -z-10">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-500/5 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-500/5 blur-[120px] rounded-full" />
      </div>

      <header className="border-b border-slate-100 bg-white/80 backdrop-blur-xl sticky top-0 z-[60]">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <button onClick={() => setCurrentView('studio')} className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-500/20 rotate-3">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
            <div className="text-left">
              <h1 className="text-xl font-black tracking-tighter text-slate-900">PosterFlow<span className="text-indigo-600">AI</span></h1>
              <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-[0.4em]">Creative Director Edition</span>
            </div>
          </button>
          <div className="flex items-center gap-8">
            <nav className="hidden md:flex items-center gap-8">
              <button 
                onClick={() => setCurrentView('studio')}
                className={`text-[10px] font-black uppercase tracking-widest transition-colors ${currentView === 'studio' ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-900'}`}
              >
                Studio
              </button>
              <button 
                onClick={() => setCurrentView('pricing')}
                className={`text-[10px] font-black uppercase tracking-widest transition-colors ${currentView === 'pricing' ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-900'}`}
              >
                Pricing
              </button>
            </nav>
            <div className="h-8 w-[1px] bg-slate-100" />
            <div className="flex items-center gap-4">
              {isLoggedIn ? (
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-indigo-50 border border-indigo-100 flex items-center justify-center text-[10px] font-black text-indigo-600">JD</div>
                  <button onClick={() => setIsLoggedIn(false)} className="text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-900 transition-colors">Logout</button>
                </div>
              ) : (
                <>
                  <button onClick={() => setCurrentView('login')} className="text-[10px] font-black uppercase tracking-widest text-slate-500 hover:text-slate-900 transition-colors">Login</button>
                  <button onClick={() => setCurrentView('signup')} className="px-5 py-2.5 bg-indigo-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-600/10">Get Started</button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 mt-12 mb-32">
        {renderContent()}
      </main>

      <AIAgent />

      <footer className="border-t border-slate-100 py-12 bg-slate-50/50">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-4">
            <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-[10px] font-black shadow-sm">PF</div>
            <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">© 2024 PosterFlow Studio.</p>
          </div>
          <div className="flex gap-10">
            {['Instagram', 'Twitter', 'Pinterest'].map(social => (
              <a key={social} href="#" className="text-[10px] font-black text-slate-400 hover:text-indigo-600 uppercase tracking-[0.2em] transition-colors">{social}</a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;