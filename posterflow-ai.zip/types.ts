
export enum PosterCategory {
  WEDDING = 'Wedding',
  STUDENT_PROJECT = 'Student Project',
  STICKER = 'Creative Sticker',
  EDUCATIONAL = 'Educational Info',
  EVENT_PROMO = 'Event Promotion',
  MOTIVATIONAL = 'Motivational',
  GENERAL = 'General Design'
}

export enum PosterMood {
  MINIMALIST = 'Minimalist',
  MAXIMALIST = 'Vibrant Maximalist',
  EXPRESSIVE = 'Expressive',
  VINTAGE = 'Vintage',
  FUTURISTIC = 'Futuristic',
  ELEGANT = 'Elegant',
  BOLD = 'Bold',
  PLAYFUL = 'Playful'
}

export enum AspectRatio {
  THREE_FOUR = '3:4',
  NINE_SIXTEEN = '9:16',
  ONE_ONE = '1:1'
}

export interface PosterConfig {
  category: PosterCategory;
  title: string;
  subtitle: string;
  topic: string;
  mood: PosterMood;
  colors: string;
  aspectRatio: AspectRatio;
  highQuality: boolean;
}

export interface GeneratedPoster {
  id: string;
  url: string;
  config: PosterConfig;
  timestamp: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export type AppView = 'studio' | 'pricing' | 'login' | 'signup' | '2fa';
