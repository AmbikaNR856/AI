
import React, { useState } from 'react';
import { PosterConfig, PosterMood, AspectRatio, PosterCategory } from '../types';

interface PosterFormProps {
  onGenerate: (config: PosterConfig) => void;
  isGenerating: boolean;
}

const PosterForm: React.FC<PosterFormProps> = ({ onGenerate, isGenerating }) => {
  const [config, setConfig] = useState<PosterConfig>({
    category: PosterCategory.GENERAL,
    title: '',
    subtitle: '',
    topic: '',
    mood: PosterMood.MINIMALIST,
    colors: 'Sky Blue and Slate Gray',
    aspectRatio: AspectRatio.THREE_FOUR,
    highQuality: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(config);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-8 rounded-3xl border border-slate-200 shadow-2xl sticky top-8">
      <div className="border-b border-slate-100 pb-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-black text-slate-900 bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600">Poster Studio</h2>
          <span className="text-[10px] font-black text-indigo-600 bg-indigo-50 px-2 py-1 rounded">V2.0</span>
        </div>
        <p className="text-slate-500 text-xs mt-1">Strategic, purpose-driven AI design.</p>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-[10px] font-bold text-indigo-600 uppercase tracking-[0.2em] mb-2">Poster Purpose</label>
          <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto scrollbar-hide pr-1">
            {Object.values(PosterCategory).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setConfig({ ...config, category: cat })}
                className={`px-3 py-2 rounded-xl text-[10px] font-bold transition-all border ${
                  config.category === cat 
                    ? 'bg-indigo-600 border-indigo-400 text-white shadow-lg shadow-indigo-600/20' 
                    : 'bg-slate-50 border-slate-200 text-slate-500 hover:border-indigo-300 hover:text-indigo-600'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-bold text-indigo-600 uppercase tracking-[0.2em] mb-2">Core Message & Topic</label>
          <textarea 
            rows={2}
            placeholder="What is this poster for? (e.g., A rally for climate change, a Techno festival, an inspiring quote...)"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all resize-none"
            value={config.topic}
            onChange={(e) => setConfig({ ...config, topic: e.target.value })}
            required
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Impact Title</label>
            <input 
              type="text" 
              placeholder="Primary Hook"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500/20"
              value={config.title}
              onChange={(e) => setConfig({ ...config, title: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Context/Date</label>
            <input 
              type="text" 
              placeholder="Venue or Quote"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500/20"
              value={config.subtitle}
              onChange={(e) => setConfig({ ...config, subtitle: e.target.value })}
            />
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-bold text-indigo-600 uppercase tracking-[0.2em] mb-2">Aesthetic & Hierarchy</label>
          <div className="flex flex-wrap gap-2">
            {Object.values(PosterMood).map((mood) => (
              <button
                key={mood}
                type="button"
                onClick={() => setConfig({ ...config, mood: mood })}
                className={`px-3 py-1.5 rounded-full text-[10px] font-medium transition-all ${
                  config.mood === mood 
                    ? 'bg-indigo-600 text-white shadow-md' 
                    : 'bg-slate-50 text-slate-500 hover:text-slate-900 border border-slate-200'
                }`}
              >
                {mood}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Strategic Color Palette</label>
          <input 
            type="text" 
            placeholder="e.g. Earthy browns and vibrant oranges"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500/20"
            value={config.colors}
            onChange={(e) => setConfig({ ...config, colors: e.target.value })}
          />
        </div>

        <div className="flex items-center justify-between p-4 bg-indigo-50/50 border border-indigo-100 rounded-2xl group hover:bg-indigo-50 transition-colors">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${config.highQuality ? 'bg-indigo-600 text-white rotate-3 shadow-lg shadow-indigo-500/40' : 'bg-slate-200 text-slate-500'}`}>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
              </svg>
            </div>
            <div>
              <span className="block text-xs font-black text-slate-900 uppercase tracking-tighter">Pro Engine</span>
              <span className="block text-[9px] text-slate-500 font-bold uppercase tracking-widest">2K Masterpiece Mode</span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setConfig({ ...config, highQuality: !config.highQuality })}
            className={`w-12 h-6 rounded-full transition-colors relative ${config.highQuality ? 'bg-indigo-600' : 'bg-slate-300'}`}
          >
            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${config.highQuality ? 'left-7' : 'left-1 shadow-sm'}`} />
          </button>
        </div>
      </div>

      <button 
        type="submit" 
        disabled={isGenerating || !config.topic}
        className={`w-full py-4 rounded-2xl font-black text-sm uppercase tracking-[0.2em] shadow-xl transition-all relative overflow-hidden group ${
          isGenerating || !config.topic 
            ? 'bg-slate-100 text-slate-400' 
            : 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:shadow-indigo-500/30'
        }`}
      >
        <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform" />
        {isGenerating ? (
           <div className="flex items-center justify-center gap-2">
             <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24">
               <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
               <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
             </svg>
             Rendering Masterpiece...
           </div>
        ) : 'Generate Impact'}
      </button>
    </form>
  );
};

export default PosterForm;