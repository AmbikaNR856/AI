
import React from 'react';
import { GeneratedPoster } from '../types';

interface PosterCardProps {
  poster: GeneratedPoster;
  onDownload: (url: string, title: string) => void;
  onDelete: (id: string) => void;
}

const PosterCard: React.FC<PosterCardProps> = ({ poster, onDownload, onDelete }) => {
  return (
    <div className="group relative bg-white rounded-2xl overflow-hidden border border-slate-200 transition-all hover:border-indigo-400 hover:shadow-2xl hover:shadow-indigo-500/10">
      <div className="aspect-[3/4] overflow-hidden bg-slate-100">
        <img 
          src={poster.url} 
          alt={poster.config.title} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          loading="lazy"
        />
      </div>
      
      <div className="p-4 bg-white/95 backdrop-blur-sm border-t border-slate-100">
        <h3 className="text-slate-900 font-bold truncate text-sm mb-1">{poster.config.title || 'Untitled Masterpiece'}</h3>
        <p className="text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-3">{new Date(poster.timestamp).toLocaleDateString()}</p>
        
        <div className="flex gap-2">
          <button 
            onClick={() => onDownload(poster.url, poster.config.title)}
            className="flex-1 bg-indigo-600 text-white py-2 rounded-xl text-xs font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-600/10"
          >
            Download
          </button>
          <button 
            onClick={() => onDelete(poster.id)}
            className="px-3 bg-slate-100 text-slate-400 py-2 rounded-xl text-xs hover:bg-red-50 hover:text-red-600 transition-all border border-slate-200 hover:border-red-200"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default PosterCard;