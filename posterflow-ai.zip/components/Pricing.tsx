
import React from 'react';

const Pricing: React.FC = () => {
  const tiers = [
    {
      name: 'Starter',
      price: '$0',
      description: 'Perfect for students and casual creators.',
      features: ['5 HD Designs / month', 'Standard AI Engine', 'Basic Templates', 'Community Support'],
      cta: 'Get Started',
      popular: false
    },
    {
      name: 'Pro',
      price: '$19',
      description: 'The creative choice for design enthusiasts.',
      features: ['Unlimited Designs', 'Pro 2K Engine', 'Priority Generation', 'Advanced Styles', 'Direct Download'],
      cta: 'Go Pro',
      popular: true
    },
    {
      name: 'Agency',
      price: '$49',
      description: 'Built for high-volume marketing teams.',
      features: ['Bulk Export', '4K Masterpiece Mode', 'API Access', 'Custom AI Fine-tuning', '24/7 Concierge'],
      cta: 'Contact Sales',
      popular: false
    }
  ];

  return (
    <div className="py-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-black text-slate-900 mb-4 tracking-tighter">Choose Your Creative Power</h2>
        <p className="text-slate-500 text-lg">Simple pricing for posters that make an impact.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto px-4">
        {tiers.map((tier) => (
          <div 
            key={tier.name}
            className={`relative p-8 rounded-[40px] border transition-all duration-500 hover:scale-[1.02] ${
              tier.popular 
                ? 'bg-white border-indigo-600 shadow-2xl shadow-indigo-600/10' 
                : 'bg-white border-slate-100 shadow-xl shadow-slate-200/50'
            }`}
          >
            {tier.popular && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-indigo-600 text-white text-[10px] font-black uppercase tracking-widest px-4 py-1.5 rounded-full shadow-lg">
                Most Popular
              </div>
            )}
            
            <div className="mb-8">
              <h3 className="text-2xl font-black text-slate-900 mb-2">{tier.name}</h3>
              <p className="text-slate-500 text-sm h-10">{tier.description}</p>
            </div>

            <div className="mb-8">
              <span className="text-5xl font-black text-slate-900">{tier.price}</span>
              <span className="text-slate-400 text-sm ml-2 font-bold">/ month</span>
            </div>

            <ul className="space-y-4 mb-10">
              {tier.features.map((feature) => (
                <li key={feature} className="flex items-center gap-3 text-slate-600 text-sm font-medium">
                  <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${tier.popular ? 'text-indigo-600' : 'text-slate-400'}`} viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  {feature}
                </li>
              ))}
            </ul>

            <button className={`w-full py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all ${
              tier.popular 
                ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-600/20' 
                : 'bg-slate-100 text-slate-900 hover:bg-slate-200'
            }`}>
              {tier.cta}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Pricing;