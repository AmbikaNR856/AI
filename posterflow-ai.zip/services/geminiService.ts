
import { GoogleGenAI } from "@google/genai";
import { PosterConfig, PosterCategory, ChatMessage, PosterMood } from "../types";

export const generatePosterImage = async (config: PosterConfig): Promise<string> => {
  const modelName = config.highQuality ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  let categoryInstruction = "";
  switch (config.category) {
    case PosterCategory.WEDDING:
      categoryInstruction = "Style: Elegant standard wedding design, sophisticated floral or geometric borders, luxury feel, professional wedding photography style, clean and romantic, classic typography.";
      break;
    case PosterCategory.STUDENT_PROJECT:
      categoryInstruction = "Style: Clean academic presentation, modular layout, professional diagrams, technical typography, student project vibe.";
      break;
    case PosterCategory.STICKER:
      categoryInstruction = "Style: Vector sticker art, bold lines, white die-cut border, vibrant colors, isolated on simple background, playful.";
      break;
    case PosterCategory.EDUCATIONAL:
      categoryInstruction = "Style: Infographic, educational poster, clear hierarchy, legible text blocks, icons, informative layout.";
      break;
    case PosterCategory.EVENT_PROMO:
      categoryInstruction = "Style: High-energy event promotion, eye-catching imagery, high contrast, clear date/venue hierarchy, dynamic composition.";
      break;
    case PosterCategory.MOTIVATIONAL:
      categoryInstruction = "Style: Motivational poster, inspiring scenery or abstract art, large impactful typography, simple but profound layout.";
      break;
    default:
      categoryInstruction = "Style: Professional graphic design poster.";
  }

  const hierarchyRule = "Ensure a strong visual hierarchy where the Title is the focal point, followed by the subtitle. Use negative space strategically.";
  const moodStyle = config.mood === PosterMood.MAXIMALIST 
    ? "Visual Style: Vibrant Maximalism. Use layering, patterns, textures, and rich color depth to grab attention."
    : config.mood === PosterMood.MINIMALIST
    ? "Visual Style: Minimalism. Focus on essential elements, clean lines, and significant white space for maximum impact."
    : `Visual Style: ${config.mood}.`;

  const prompt = `
    Task: Design a high-impact, professional ${config.category} for "${config.topic}".
    Primary Title: "${config.title}"
    Secondary Message: "${config.subtitle}"
    Color Palette: ${config.colors}
    
    Design Constraints:
    1. ${moodStyle}
    2. ${categoryInstruction}
    3. ${hierarchyRule}
    4. Strategic use of typography: choose fonts that reflect the tone.
    5. Clear and impactful messaging: ensure the text is legible and visually integrated.
    6. Vertical orientation.
    7. No messy text artifacts; treat text as a graphic design element.
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: { parts: [{ text: prompt }] },
      config: {
        imageConfig: {
          aspectRatio: config.aspectRatio,
          ...(config.highQuality ? { imageSize: "2K" } : {})
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
    }
    throw new Error("No image data found");
  } catch (error: any) {
    if (error.message?.includes("Requested entity was not found")) throw new Error("API_KEY_RESET_REQUIRED");
    throw error;
  }
};

export const getAgentResponse = async (history: ChatMessage[]): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const contents = history.map(m => ({
    role: m.role,
    parts: [{ text: m.text }]
  }));

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents,
    config: {
      systemInstruction: `You are 'Flow', the friendly AI Creative Director for PosterFlow AI. 
      Your goal is to guide users (students, designers, event organizers, wedding planners) through creating high-impact posters.
      Advise them on:
      - Visual Hierarchy (Title size vs Subtitle).
      - Minimalism vs Maximalism (When to use which).
      - Impactful messaging (How to phrase their cause or event).
      - Strategic color choices (e.g. 'Gold and Cream for weddings', 'Neon for events').
      Be concise, encouraging, and vibrant. Keep your answers under 3 sentences.`
    }
  });

  return response.text || "I'm here to help you design!";
};
